% Projecto de recomendação de filmes 

%filme(Titulo,                   Genero,    Ano,         Diretor,           AtorPrincipal,    Avaliacao,       ClassificacaoEtaria)
 filme(o_amanhecer_dos_titas,    acao,      2025,        carlos_lima,       joana_reis,        9.2,                    14).
 filme(sonhos_de_andromeda,      ficcao,    2025,        mariana_costa,     luciana_alves,     8.7,                    12).
 filme(misterio_em_luanda,       suspense,  2025,        fernando_silva,    ana_dias,          7.8,                    16).
 filme(a_ultima_esperanca,       drama,     2025,        joao_castro,       marisa_moura,      9.0,                    12).
 filme(guardioes_do_tempo,       acao,      2025,        teresa_ramos,      beatriz_gomes,     8.5,                    14).
 filme(coracao_de_pedra,         drama,     2025,        carlos_lima,       tiago_lopes,       7.5,                    12).
 filme(rebeldes_do_vento,        aventura,  2025,        mariana_costa,     joana_reis,        8.0,                    10).
 filme(sombras_do_norte,         terror,    2025,        joao_castro,       ricardo_pinto,     7.9,                    18).
 filme(codigos_do_destino,       ficcao,    2025,        fernando_silva,    miguel_freitas,    8.6,                    14).
 filme(noites_tropicais,         comedia,   2025,        teresa_ramos,      luciana_alves,     8.3,                    12).
 filme(inferno_branco,           terror,    2025,        carlos_lima,       ricardo_pinto,     8.1,                    18).
 filme(luz_em_angola,            drama,     2025,        mariana_costa,     beatriz_gomes,     9.4,                    10).
 filme(asas_de_ouro,             fantasia,  2025,        fernando_silva,    marisa_moura,      7.6,                    10).
 filme(o_sopro_do_deserto,       aventura,  2025,        joao_castro,       tiago_lopes,       8.2,                    12).
 filme(rede_sombria, suspense, 2025, teresa_ramos, andre_rocha, 8.9, 16).

%Pessoas(utilizadores) da nossa base de dados
%           Nome      idade   GeneroFav  Diretorfav        Atorfav

utilizador(Osvaldo,   20,     acao,      carlos_lima,      joana_reis).
utilizador(Kialunda,  20,     drama,     joao_castro,      marisa_moura).
utilizador(Adilson,   20,     ficcao,    mariana_costa,    luciana_alves).
utilizador(Vennis,    20,     terror,    fernando_silva,   ricardo_pinto).
utilizador(Rodrigues, 12,     comedia,   teresa_ramos,     pedro_nogueira).
utilizador(Gaspar,    20,     historico, carlos_lima,     ana_dias).


recomenda(Utente, Filme) :-
    utilizador(Utente, Idade, Genero, Diretor, Ator),
    filme(Filme, Genero, _, Diretor, Ator, Nota, Class),
    Nota >= 8.0,
    Class =< Idade.


% Regras de Consulta
%recomenda(Utilizador, Filme).[recomenda os filmes que o utilizador gosta]
%filme(Titulo, drama, _, _, _, _, _).[recomenda os filmes de um gênero.]
%filme(Titulo, _, _, carlos_lima, _, _, _).[recomenda os filmes de um diretor.]
%filme(Titulo, _, _, _, _, Nota, _), Nota > 9.[recomenda filmes com avaliação acima de 9]
%filme(Titulo, _, _, _, _, _, Class), Class =< 12.[recomenda filmes com classificação etária até 12 anos]
%filme(Titulo, _, _, _, joana_reis, _, _).[recomenda filmes com determinado ator (ex: joana_reis)]
%filme(Titulo, _, 2025, _, _, _, _).[recomenda os filmes lançados em 2025]
% recomenda(ana, Filme).[recomendação de filmes para um utilizador (ex: ana)]
%recomenda(Utilizador, Filme).[mostra todas as recomendações possíveis para todos utilizzadores]





